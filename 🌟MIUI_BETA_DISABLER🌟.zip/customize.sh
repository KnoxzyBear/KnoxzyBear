###################################################################################
#
# MMT Extended Config Script
#
###################################################################################

echo -n "- Date&Time: "
date "+%c"
sleep 2
ui_print "check rom dan kernel"
sleep 2
ui_print "🌟 Kernel    : $(uname -r) "
sleep 0.5
ui_print "🌟 Rom       : $(getprop ro.product.name) "
sleep 5


# Check device
    ui_print "- Checking Device Supported..."
    ui_print " "
    ui_print " "
    sleep 5
  platform=$(getprop ro.build.version.incremental)
  model=$(getprop ro.build.version.incremental)
  if [ "$platform" == "eng.mahaja.20201218.183759" -o "eng.ubuntu.20201212.154149" ]; then
    ui_print "√ [ $model ] is supported"
    ui_print " "
    ui_print " "
    ui_print " "
  else
    abort  "× [ $model ] not supported"
    ui_print " "
    ui_print " "
    ui_print " "
  fi
sleep 0.5

ui_print "🌟MIUI MOD🌟 DYNAMIC REFRESH RATE DISABLER BETA"
sleep 5
ui_print "ADDING REFRESH RATE DISABLER CONFIGS"
ui_print "PROCESSING[•••••••]"
ui_print "[][][][10%]"
sleep 1
ui_print "[][][][][][][][][][20%]"
sleep 1
ui_print "[][][][][][][][][][][][][][][][30%]"
sleep 1
ui_print "[][][][][][][][][][][][][][][][][][][][][][40%]"
sleep 1
ui_print "[][][][][][][][][][][][][][][][][][][][][][][][][][][][50%]"
sleep 1
ui_print "[][][][][][][][][][][][][][][][][][][][][][60%]"
sleep 1
ui_print "[][][][][][][][][][][][][][][][70%]"
sleep 1
ui_print "[][][][][][][][][][80%]"
sleep 1
ui_print "[][][][][][][90%]"
sleep 1
ui_print "[][][][100%]"
sleep 1
ui_print "The Real Author Of This Magisk Module Is Knoxzy Shadow 🇵🇭🇵🇭🇵🇭🇵🇭🇵🇭🇵🇭🇵🇭"
ui_print "You can check issue Bugs and Other Stuff on https://t.me/NoBiTsKies"
sleep 1

#MINAPI=21
#MAXAPI=25
#DYNLIB=true
#DEBUG=true